import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt

# Function to apply bandpass filter
def bandpass_filter(data, lowcut, highcut, fs, order=4):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    
    if low >= 1 or high >= 1:
        raise ValueError("Invalid filter parameters. Ensure lowcut and highcut are less than Nyquist frequency.")
    
    b, a = butter(order, [low, high], btype='band')
    y = filtfilt(b, a, data)
    return y

# Load raw ECG data from CSV file
# Update the file path to the location of your CSV file
df = pd.read_csv('raw_ecg_signal.csv')
raw_ecg = df['ECG'].values  # Assuming 'ECG' is the column name

# Parameters
fs = 99  # Sampling frequency in Hz
lowcut = 0.5  # Low cut frequency in Hz
highcut = 40  # High cut frequency in Hz

# Check if filter parameters are valid
if lowcut >= 0.5 * fs or highcut >= 0.5 * fs:
    raise ValueError("Lowcut and highcut frequencies must be less than half of the sampling rate.")

# Convert raw ADC values to voltage
voltage_ecg = (raw_ecg / 1023.0) * 3.3

# Remove baseline (mean value)
baseline = np.mean(voltage_ecg)
centered_ecg = voltage_ecg - baseline

# Apply bandpass filter
filtered_ecg = bandpass_filter(centered_ecg, lowcut, highcut, fs)

# Create a time vector
time_vector = np.linspace(0, len(filtered_ecg) / fs, len(filtered_ecg))

# Save the filtered ECG values to a CSV file
filtered_df = pd.DataFrame({'Filtered_ECG': filtered_ecg})
filtered_df.to_csv('filtered_ecg_signal.csv', index=False)

# Plot the raw and filtered ECG signals
plt.figure(figsize=(12, 6))
plt.subplot(2, 1, 1)
plt.plot(time_vector, voltage_ecg, label='Raw ECG')
plt.title('Raw ECG Signal')
plt.xlabel('Time (seconds)')
plt.ylabel('Voltage (V)')
plt.legend()

plt.subplot(2, 1, 2)
plt.plot(time_vector, filtered_ecg, label='Filtered ECG', color='r')
plt.title('Filtered ECG Signal')
plt.xlabel('Time (seconds)')
plt.ylabel('Voltage (V)')
plt.legend()

plt.tight_layout()
plt.show()

print("Filtered ECG values saved to 'filtered_ecg_signal.csv'")


